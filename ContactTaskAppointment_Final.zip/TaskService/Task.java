public class Task {
    private final String taskId;
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10) throw new IllegalArgumentException("taskId invalid");
        this.taskId = taskId;
        setName(name);
        setDescription(description);
    }

    public String getTaskId() { return taskId; }

    public String getName() { return name; }
    public void setName(String name) {
        if (name == null || name.length() > 20) throw new IllegalArgumentException("name invalid");
        this.name = name;
    }

    public String getDescription() { return description; }
    public void setDescription(String description) {
        if (description == null || description.length() > 50) throw new IllegalArgumentException("description invalid");
        this.description = description;
    }
}

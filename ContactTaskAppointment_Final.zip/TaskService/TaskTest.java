import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    void validTask() {
        Task t = new Task("t1", "Title", "Describe something");
        assertEquals("t1", t.getTaskId());
        assertEquals("Title", t.getName());
        assertEquals("Describe something", t.getDescription());
    }

    @Test
    void idInvalid() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "n", "d"));
        assertThrows(IllegalArgumentException.class, () -> new Task("x".repeat(11), "n", "d"));
    }

    @Test
    void nameAndDescriptionInvalid() {
        assertThrows(IllegalArgumentException.class, () -> new Task("t1", null, "d"));
        assertThrows(IllegalArgumentException.class, () -> new Task("t1", "x".repeat(21), "d"));
        assertThrows(IllegalArgumentException.class, () -> new Task("t1", "n", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("t1", "n", "x".repeat(51)));
    }

    @Test
    void settersWork() {
        Task t = new Task("t1", "n", "d");
        t.setName("NewName");
        t.setDescription("New description");
        assertEquals("NewName", t.getName());
        assertEquals("New description", t.getDescription());
    }
}

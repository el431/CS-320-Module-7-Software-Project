import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.NoSuchElementException;

public class TaskServiceTest {
    private TaskService service;

    @BeforeEach
    void setup() {
        service = new TaskService();
        service.addTask("1", "N", "D");
    }

    @Test
    void addDuplicateThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.addTask("1", "X", "Y"));
    }

    @Test
    void deleteAndMissing() {
        service.deleteTask("1");
        assertThrows(NoSuchElementException.class, () -> service.deleteTask("1"));
    }

    @Test
    void updates() {
        service.updateName("1", "New");
        service.updateDescription("1", "New Desc");
        assertEquals("New", service.get("1").getName());
        assertEquals("New Desc", service.get("1").getDescription());
    }

    @Test
    void updateMissingThrows() {
        assertThrows(NoSuchElementException.class, () -> service.updateName("x", "N"));
    }
}

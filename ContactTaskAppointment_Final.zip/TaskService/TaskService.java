import java.util.*;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public Task get(String id) {
        Task t = tasks.get(id);
        if (t == null) throw new NoSuchElementException("No task: " + id);
        return t;
    }

    public void addTask(String id, String name, String description) {
        if (tasks.containsKey(id)) throw new IllegalArgumentException("Duplicate task id: " + id);
        tasks.put(id, new Task(id, name, description));
    }

    public void deleteTask(String id) {
        if (tasks.remove(id) == null) throw new NoSuchElementException("No task: " + id);
    }

    public void updateName(String id, String name) { get(id).setName(name); }
    public void updateDescription(String id, String description) { get(id).setDescription(description); }
}

import java.util.Objects;
import java.util.regex.Pattern;

public class Contact {
    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    private static final Pattern TEN_DIGITS = Pattern.compile("^\d{10}$");

    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        this.contactId = validateId(contactId);
        setFirstName(firstName);
        setLastName(lastName);
        setPhone(phone);
        setAddress(address);
    }

    private static String validateId(String id) {
        if (id == null || id.length() > 10) {
            throw new IllegalArgumentException("contactId must be non-null and at most 10 characters");
        }
        return id;
    }

    private static String validateLen(String value, int max, String field) {
        if (value == null || value.length() > max) {
            throw new IllegalArgumentException(field + " must be non-null and at most " + max + " characters");
        }
        return value;
    }

    public String getContactId() { return contactId; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = validateLen(firstName, 10, "firstName"); }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = validateLen(lastName, 10, "lastName"); }

    public String getPhone() { return phone; }
    public void setPhone(String phone) {
        if (phone == null || !TEN_DIGITS.matcher(phone).matches()) {
            throw new IllegalArgumentException("phone must be exactly 10 digits");
        }
        this.phone = phone;
    }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = validateLen(address, 30, "address"); }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Contact)) return false;
        Contact contact = (Contact) o;
        return contactId.equals(contact.contactId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(contactId);
    }
}

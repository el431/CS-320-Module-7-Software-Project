import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    void validContactConstructs() {
        Contact c = new Contact("id123", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("id123", c.getContactId());
        assertEquals("John", c.getFirstName());
        assertEquals("Doe", c.getLastName());
        assertEquals("1234567890", c.getPhone());
        assertEquals("123 Main St", c.getAddress());
    }

    @Test
    void idValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "A", "B", "1234567890", "addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("toolong-12345", "A", "B", "1234567890", "addr"));
    }

    @Test
    void firstNameValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", null, "B", "1234567890", "addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", "ABCDEFGHIJK", "B", "1234567890", "addr"));
    }

    @Test
    void lastNameValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", "A", null, "1234567890", "addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", "A", "ABCDEFGHIJK", "1234567890", "addr"));
    }

    @Test
    void phoneValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", "A", "B", null, "addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", "A", "B", "123", "addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", "A", "B", "123456789a", "addr"));
    }

    @Test
    void addressValidation() {
        String longAddr = "a".repeat(31);
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", "A", "B", "1234567890", null));
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", "A", "B", "1234567890", longAddr));
    }

    @Test
    void settersValidate() {
        Contact c = new Contact("id", "A", "B", "1234567890", "addr");
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("012345678"));
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName("ABCDEFGHIJK"));
        c.setFirstName("Amy");
        c.setLastName("Bee");
        c.setAddress("New Address");
        c.setPhone("0987654321");
        assertEquals("Amy", c.getFirstName());
        assertEquals("Bee", c.getLastName());
        assertEquals("New Address", c.getAddress());
        assertEquals("0987654321", c.getPhone());
    }
}

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.NoSuchElementException;

public class ContactServiceTest {
    private ContactService service;

    @BeforeEach
    void setup() {
        service = new ContactService();
        service.addContact("1", "A", "B", "1234567890", "addr");
    }

    @Test
    void addDuplicateIdThrows() {
        assertThrows(IllegalArgumentException.class, () ->
            service.addContact("1", "X", "Y", "0987654321", "place"));
    }

    @Test
    void deleteAndMissing() {
        service.deleteContact("1");
        assertThrows(NoSuchElementException.class, () -> service.deleteContact("1"));
    }

    @Test
    void updateFields() {
        service.updateFirstName("1", "Amy");
        service.updateLastName("1", "Bee");
        service.updatePhone("1", "0987654321");
        service.updateAddress("1", "New Place");
        Contact c = service.get("1");
        assertEquals("Amy", c.getFirstName());
        assertEquals("Bee", c.getLastName());
        assertEquals("0987654321", c.getPhone());
        assertEquals("New Place", c.getAddress());
    }

    @Test
    void updateMissingThrows() {
        assertThrows(NoSuchElementException.class, () -> service.updateFirstName("x", "Name"));
    }
}

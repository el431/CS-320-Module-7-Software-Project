import java.util.*;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    public Collection<Contact> getAll() { return Collections.unmodifiableCollection(contacts.values()); }

    public Contact get(String contactId) {
        Contact c = contacts.get(contactId);
        if (c == null) throw new NoSuchElementException("No contact: " + contactId);
        return c;
    }

    public void addContact(String contactId, String firstName, String lastName, String phone, String address) {
        if (contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Duplicate contact id: " + contactId);
        }
        Contact c = new Contact(contactId, firstName, lastName, phone, address);
        contacts.put(contactId, c);
    }

    public void deleteContact(String contactId) {
        if (contacts.remove(contactId) == null) throw new NoSuchElementException("No contact: " + contactId);
    }

    public void updateFirstName(String contactId, String firstName) { get(contactId).setFirstName(firstName); }
    public void updateLastName(String contactId, String lastName) { get(contactId).setLastName(lastName); }
    public void updatePhone(String contactId, String phone) { get(contactId).setPhone(phone); }
    public void updateAddress(String contactId, String address) { get(contactId).setAddress(address); }
}

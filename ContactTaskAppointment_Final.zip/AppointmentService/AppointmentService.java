import java.util.*;

public class AppointmentService {
    private final Map<String, Appointment> appts = new HashMap<>();

    public Appointment get(String id) {
        Appointment a = appts.get(id);
        if (a == null) throw new NoSuchElementException("No appointment: " + id);
        return a;
    }

    public void addAppointment(String id, Date when, String description) {
        if (appts.containsKey(id)) throw new IllegalArgumentException("Duplicate appointment id: " + id);
        appts.put(id, new Appointment(id, when, description));
    }

    public void deleteAppointment(String id) {
        if (appts.remove(id) == null) throw new NoSuchElementException("No appointment: " + id);
    }
}

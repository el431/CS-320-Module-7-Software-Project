import java.util.Date;

public class Appointment {
    private final String appointmentId;
    private final Date appointmentDate;
    private String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("appointmentId invalid");
        }
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("appointmentDate must be in the future or present");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("description invalid");
        }
        this.appointmentId = appointmentId;
        this.appointmentDate = new Date(appointmentDate.getTime());
        this.description = description;
    }

    public String getAppointmentId() { return appointmentId; }

    public Date getAppointmentDate() { return new Date(appointmentDate.getTime()); }

    public String getDescription() { return description; }
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("description invalid");
        }
        this.description = description;
    }
}

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

public class AppointmentTest {

    @Test
    void validAppointment() {
        Date future = new Date(System.currentTimeMillis() + 1_000);
        Appointment a = new Appointment("a1", future, "Checkup");
        assertEquals("a1", a.getAppointmentId());
        assertEquals("Checkup", a.getDescription());
        assertTrue(a.getAppointmentDate().getTime() >= future.getTime());
    }

    @Test
    void idAndDateValidation() {
        Date future = new Date(System.currentTimeMillis() + 1_000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, future, "ok"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("x".repeat(11), future, "ok"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("a", null, "ok"));
        Date past = new Date(System.currentTimeMillis() - 10_000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("a", past, "ok"));
    }

    @Test
    void descriptionValidationAndDefensiveCopy() {
        Date future = new Date(System.currentTimeMillis() + 1_000);
        Appointment a = new Appointment("a1", future, "ok");
        assertThrows(IllegalArgumentException.class, () -> a.setDescription(null));
        assertThrows(IllegalArgumentException.class, () -> a.setDescription("x".repeat(51)));

        Date returned = a.getAppointmentDate();
        returned.setTime(returned.getTime() + 10_000);
        assertTrue(a.getAppointmentDate().getTime() >= future.getTime());
    }
}

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.NoSuchElementException;

public class AppointmentServiceTest {
    private AppointmentService service;
    private Date future;

    @BeforeEach
    void setup() {
        service = new AppointmentService();
        future = new Date(System.currentTimeMillis() + 1_000);
        service.addAppointment("1", future, "Dentist");
    }

    @Test
    void addDuplicateThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment("1", future, "X"));
    }

    @Test
    void deleteAndMissing() {
        service.deleteAppointment("1");
        assertThrows(NoSuchElementException.class, () -> service.deleteAppointment("1"));
    }
}
